// Maçları Yükle
function loadMatches() {
  fetch('/api/matches')
    .then(res => res.json())
    .then(data => {
      const matches = data.matches || data;
      const table = document.getElementById('matchesTable');
      table.innerHTML = '';
      matches.forEach((m, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${idx}</td>
          <td>${m.homeTeam}</td>
          <td>${m.awayTeam}</td>
          <td>${m.date}</td>
          <td>${m.time}</td>
          <td>${m.prediction || '-'}</td>
          <td><button onclick="toggleFeatured(${idx})">${m.featured ? 'Kaldır' : 'Ekle'}</button></td>
          <td><button onclick="deleteMatch(${idx})">Sil</button></td>
        `;
        table.appendChild(tr);
      });
    });
}

// Maç Ekle
function addMatch() {
  const homeTeam = document.getElementById('homeTeam').value;
  const awayTeam = document.getElementById('awayTeam').value;
  const date = document.getElementById('matchDate').value;
  const time = document.getElementById('matchTime').value;
  const prediction = document.getElementById('matchPrediction').value;

  fetch('/api/matches', {
    method: 'POST',
    headers: { 
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('adminToken')
    },
    body: JSON.stringify({ homeTeam, awayTeam, date, time, prediction })
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    loadMatches();
  });
}

// Maç Sil
function deleteMatch(index) {
  fetch(`/api/matches/${index}`, { 
    method: 'DELETE',
    headers: { 'Authorization': localStorage.getItem('adminToken') }
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    loadMatches();
  });
}

// Öne Çıkarma
function toggleFeatured(index) {
  fetch(`/api/matches/feature/${index}`, { 
    method: 'PATCH',
    headers: { 'Authorization': localStorage.getItem('adminToken') }
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    loadMatches();
  });
}

// Sayfa Ekle
function addPage() {
  const title = document.getElementById('pageTitle').value;
  const slug = document.getElementById('pageSlug').value;
  const content = document.getElementById('pageContent').value;
  const parent = document.getElementById('pageParent').value || null;
  const visibility = document.getElementById('pageVisibility').value;
  const rolesAllowed = Array.from(document.querySelectorAll('input[type=checkbox]:checked')).map(c => c.value);

  fetch('/api/pages', {
    method: 'POST',
    headers: { 
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('adminToken')
    },
    body: JSON.stringify({ title, slug, content, parent, visibility, rolesAllowed })
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    loadPages();
  });
}

// Sayfaları Listele
function loadPages() {
  fetch('/api/pages')
    .then(res => res.json())
    .then(pages => {
      const table = document.getElementById('pagesTable');
      const parentSelect = document.getElementById('pageParent');
      table.innerHTML = '';
      parentSelect.innerHTML = '<option value="">Ana Sayfa</option>';

      pages.forEach(p => {
        // Tabloya satır ekle
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td>${p.title}</td>
          <td>${p.slug}</td>
          <td>${p.visibility || '-'}</td>
          <td>${p.rolesAllowed ? p.rolesAllowed.join(', ') : '-'}</td>
          <td>${p.parent || '-'}</td>
          <td><button onclick="previewPage('${p.slug}')">Ön İzle</button></td>
          <td><button onclick="editPage('${p.slug}')">Düzenle</button></td>
          <td><button onclick="deletePage('${p.slug}')">Sil</button></td>
        `;
        table.appendChild(tr);

        // Üst sayfa seçimine ekle
        parentSelect.innerHTML += `<option value="${p.slug}">${p.title}</option>`;
      });
    });
}

function savePage() {
  const editingSlug = document.getElementById('editingSlug').value;
  const title = document.getElementById('pageTitle').value;
  const slug = document.getElementById('pageSlug').value;
  const content = document.getElementById('pageContent').value;
  const parent = document.getElementById('pageParent').value || null;
  const visibility = document.getElementById('pageVisibility').value;
  const rolesAllowed = Array.from(document.querySelectorAll('input[type=checkbox]:checked')).map(c => c.value);

  const method = editingSlug ? 'PUT' : 'POST';
  const url = editingSlug ? `/api/pages/${editingSlug}` : '/api/pages';

  fetch(url, {
    method: method,
    headers: { 
      'Content-Type': 'application/json',
      'Authorization': localStorage.getItem('adminToken')
    },
    body: JSON.stringify({ title, slug, content, parent, visibility, rolesAllowed })
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    resetPageForm();
    loadPages();
  });
}

function deletePage(slug) {
  if(!confirm('Silmek istediğinize emin misiniz?')) return;
  fetch(`/api/pages/${slug}`, {
    method: 'DELETE',
    headers: { 'Authorization': localStorage.getItem('adminToken') }
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    loadPages();
  });
}

function editPage(slug) {
  fetch(`/api/pages/view/${slug}`)
    .then(res => res.json())
    .then(page => {
      document.getElementById('editingSlug').value = page.slug;
      document.getElementById('pageTitle').value = page.title;
      document.getElementById('pageSlug').value = page.slug;
      document.getElementById('pageContent').value = page.content;
      document.getElementById('pageParent').value = page.parent || '';
      document.getElementById('pageVisibility').value = page.visibility || 'public';

      document.querySelectorAll('input[type=checkbox]').forEach(c => {
        c.checked = page.rolesAllowed && page.rolesAllowed.includes(c.value);
      });
    });
}

function previewPage(slug) {
  window.open(`/api/pages/view/${slug}`, '_blank');
}

function resetPageForm() {
  document.getElementById('editingSlug').value = '';
  document.getElementById('pageTitle').value = '';
  document.getElementById('pageSlug').value = '';
  document.getElementById('pageContent').value = '';
  document.getElementById('pageParent').value = '';
  document.getElementById('pageVisibility').value = 'public';
  document.querySelectorAll('input[type=checkbox]').forEach(c => c.checked = false);
}
function addAd() {
  const adImage = document.getElementById('adImage').files[0];
  const adLink = document.getElementById('adLink').value;

  if (!adImage || !adLink) {
    alert("Lütfen görsel seçin ve link girin.");
    return;
  }

  const formData = new FormData();
  formData.append('image', adImage);
  formData.append('link', adLink);

  fetch('/api/ads', {
    method: 'POST',
    headers: {
      'Authorization': localStorage.getItem('adminToken')
    },
    body: formData
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    document.getElementById('adImage').value = "";
    document.getElementById('adLink').value = "";
    loadAds();
  })
  .catch(err => {
    console.error(err);
    alert("Reklam eklenirken hata oluştu.");
  });
}

function loadAds() {
  fetch('/api/ads')
    .then(res => res.json())
    .then(ads => {
      const table = document.getElementById('adsTable');
      table.innerHTML = '';
      ads.forEach((ad, idx) => {
        const tr = document.createElement('tr');
        tr.innerHTML = `
          <td><img src="${ad.image}" alt="ad" width="100"></td>
          <td><a href="${ad.link}" target="_blank">${ad.link}</a></td>
          <td><button onclick="deleteAd(${idx})">Sil</button></td>
        `;
        table.appendChild(tr);
      });
    });
}

function deleteAd(index) {
  if (!confirm('Reklamı silmek istediğinize emin misiniz?')) return;

  fetch(`/api/ads/${index}`, {
    method: 'DELETE',
    headers: { 'Authorization': localStorage.getItem('adminToken') }
  })
  .then(res => res.json())
  .then(data => {
    alert(data.message);
    loadAds();
  });
}
