const fs = require('fs');
const path = require('path');
const dbPath = path.join(__dirname, '..', 'data', 'pages.json');

function readPages() {
  try {
    const data = fs.readFileSync(dbPath, 'utf8');
    return JSON.parse(data);
  } catch {
    return [];
  }
}

function writePages(pages) {
  fs.writeFileSync(dbPath, JSON.stringify(pages, null, 2), 'utf8');
}

// Tüm sayfaları getir
function getAllPages(req, res) {
  const pages = readPages();
  res.json(pages);
}

// Sayfa oluştur
function createPage(req, res) {
  const { title, slug, content, parent, visibility, rolesAllowed } = req.body;
  const pages = readPages();

  if (pages.find(p => p.slug === slug)) {
    return res.status(400).json({ message: 'Bu slug zaten mevcut' });
  }

  const newPage = { title, slug, content, parent, visibility, rolesAllowed };
  pages.push(newPage);
  writePages(pages);

  res.json({ message: 'Sayfa oluşturuldu' });
}

// Sayfa güncelle
function updatePage(req, res) {
  const { slug } = req.params;
  const { title, content, parent, visibility, rolesAllowed } = req.body;
  const pages = readPages();
  const index = pages.findIndex(p => p.slug === slug);

  if (index === -1) return res.status(404).json({ message: 'Sayfa bulunamadı' });

  pages[index] = {
    ...pages[index],
    title,
    content,
    parent,
    visibility,
    rolesAllowed
  };

  writePages(pages);
  res.json({ message: 'Sayfa güncellendi' });
}

// Sayfa sil
function deletePage(req, res) {
  const { slug } = req.params;
  let pages = readPages();
  const page = pages.find(p => p.slug === slug);

  if (!page) return res.status(404).json({ message: 'Sayfa bulunamadı' });

  pages = pages.filter(p => p.slug !== slug);
  writePages(pages);
  res.json({ message: 'Sayfa silindi' });
}

// Tek sayfa önizleme
function getPage(req, res) {
  const { slug } = req.params;
  const pages = readPages();
  const page = pages.find(p => p.slug === slug);
  if (!page) return res.status(404).json({ message: 'Sayfa bulunamadı' });

  res.json(page);
}

module.exports = {
  getAllPages,
  createPage,
  updatePage,
  deletePage,
  getPage
};
