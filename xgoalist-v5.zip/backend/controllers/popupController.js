// backend/controllers/popupController.js
const fs = require('fs');
const path = require('path');
const POPUP_PATH = path.join(__dirname, '..', 'data', 'popups.json');

// Popupları oku
function readPopups() {
  if (!fs.existsSync(POPUP_PATH)) return [];
  const content = fs.readFileSync(POPUP_PATH, 'utf-8');
  return JSON.parse(content);
}

// Popupları yaz
function writePopups(data) {
  fs.writeFileSync(POPUP_PATH, JSON.stringify(data, null, 2));
}

// Tüm popup'ları getir
exports.getAllPopups = (req, res) => {
  const popups = readPopups();
  res.json(popups);
};

// Popup ekle
exports.addPopup = (req, res) => {
  const { title, type, content, page, mustAgree, link } = req.body;
  const media = req.file ? `/uploads/${req.file.filename}` : null;

  const popups = readPopups();
  const newPopup = {
    id: Date.now(),
    title,
    type, // info / ad
    content,
    media,
    page,
    mustAgree,
    link
  };

  popups.push(newPopup);
  writePopups(popups);
  res.json({ message: 'Popup eklendi', popup: newPopup });
};

// Popup sil
exports.deletePopup = (req, res) => {
  const { id } = req.params;
  let popups = readPopups();
  popups = popups.filter(p => p.id != id);
  writePopups(popups);
  res.json({ message: 'Popup silindi' });
};
