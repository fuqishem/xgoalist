const fs = require('fs');
const path = require('path');
const dataPath = path.join(__dirname, '..', 'data', 'matches.json');

// JSON dosyasını oku
function readMatches() {
  if (!fs.existsSync(dataPath)) return [];
  return JSON.parse(fs.readFileSync(dataPath, 'utf8'));
}

// JSON dosyasına yaz
function writeMatches(matches) {
  fs.writeFileSync(dataPath, JSON.stringify(matches, null, 2), 'utf8');
}

exports.getAllMatches = (req, res) => {
  const matches = readMatches();
  res.json(matches);
};

exports.addMatch = (req, res) => {
  const { homeTeam, awayTeam, date, time, prediction } = req.body;
  if (!homeTeam || !awayTeam || !date || !time) {
    return res.status(400).json({ message: 'Eksik bilgi var' });
  }

  const matches = readMatches();
  matches.push({ homeTeam, awayTeam, date, time, prediction });
  writeMatches(matches);
  res.json({ message: 'Maç eklendi' });
};

exports.deleteMatch = (req, res) => {
  const index = parseInt(req.params.index);
  const matches = readMatches();
  if (index >= 0 && index < matches.length) {
    matches.splice(index, 1);
    writeMatches(matches);
    res.json({ message: 'Maç silindi' });
  } else {
    res.status(404).json({ message: 'Maç bulunamadı' });
  }
};

exports.toggleFeatured = (req, res) => {
  const index = parseInt(req.params.index);
  const matches = readMatches();
  if (index >= 0 && index < matches.length) {
    matches[index].featured = !matches[index].featured;
    writeMatches(matches);
    res.json({ message: matches[index].featured ? 'Öne çıkarıldı' : 'Öne çıkarma kaldırıldı' });
  } else {
    res.status(404).json({ message: 'Maç bulunamadı' });
  }
};
