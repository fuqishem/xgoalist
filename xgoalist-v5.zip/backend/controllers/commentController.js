const fs = require('fs');
const path = require('path');
const { verifyToken } = require('../middleware/auth');

const filePath = path.join(__dirname, '../../data/comments.json');

function readComments() {
  if (!fs.existsSync(filePath)) return [];
  const content = fs.readFileSync(filePath);
  return JSON.parse(content);
}

function writeComments(comments) {
  fs.writeFileSync(filePath, JSON.stringify(comments, null, 2));
}

// Yorumları listele
exports.getComments = (req, res) => {
  const comments = readComments();
  res.json(comments);
};

// Yeni yorum ekle
exports.addComment = (req, res) => {
  const { matchIndex, comment, prediction } = req.body;
  const username = req.user?.email || 'Anonim';

  if (!comment || matchIndex === undefined) {
    return res.status(400).json({ message: 'Eksik bilgi' });
  }

  const comments = readComments();
  comments.push({
    matchIndex,
    comment,
    prediction,
    username,
    date: new Date().toISOString()
  });

  writeComments(comments);
  res.json({ message: 'Yorum eklendi' });
};

// Yorum sil
exports.deleteComment = (req, res) => {
  const index = parseInt(req.params.index);
  if (isNaN(index)) return res.status(400).json({ message: 'Geçersiz index' });

  const comments = readComments();
  if (index < 0 || index >= comments.length) {
    return res.status(404).json({ message: 'Yorum bulunamadı' });
  }

  comments.splice(index, 1);
  writeComments(comments);
  res.json({ message: 'Yorum silindi' });
};
