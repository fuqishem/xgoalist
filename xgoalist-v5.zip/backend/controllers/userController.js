const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const sendMail = require('../utils/sendMail');

const usersFile = path.join(__dirname, '../data/users.json');
const SECRET_KEY = 'xgoalist_secret_key';

function loadUsers() {
  if (!fs.existsSync(usersFile)) fs.writeFileSync(usersFile, '[]');
  return JSON.parse(fs.readFileSync(usersFile, 'utf-8'));
}

function saveUsers(users) {
  fs.writeFileSync(usersFile, JSON.stringify(users, null, 2));
}

function findUserByEmail(email) {
  return loadUsers().find(u => u.email === email);
}

exports.register = (req, res) => {
  const { email, username, password, confirmPassword, agreementAccepted } = req.body;
  if (!email || !username || !password || !confirmPassword) {
    return res.status(400).json({ message: 'Tüm alanlar zorunludur' });
  }
  if (password !== confirmPassword) {
    return res.status(400).json({ message: 'Şifreler eşleşmiyor' });
  }
  if (!agreementAccepted) {
    return res.status(400).json({ message: 'Üyelik sözleşmesi kabul edilmelidir' });
  }

  const users = loadUsers();
  if (users.find(u => u.email === email)) {
    return res.status(409).json({ message: 'Bu email zaten kayıtlı' });
  }

  const hash = bcrypt.hashSync(password, 10);
  const newUser = {
    id: uuidv4(),
    username,
    email,
    password: hash,
    role: 'user',
    date: new Date().toISOString(),
    lastActive: new Date().toISOString()
  };

  users.push(newUser);
  saveUsers(users);
  res.json({ message: 'Kayıt başarılı' });
};

exports.login = (req, res) => {
  const { email, password } = req.body;
  const user = findUserByEmail(email);
  if (!user) return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
  if (!bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ message: 'Hatalı şifre' });
  }

  user.lastActive = new Date().toISOString();
  saveUsers(loadUsers().map(u => (u.email === email ? user : u)));

  const token = jwt.sign({ id: user.id, email: user.email, role: user.role }, SECRET_KEY, { expiresIn: '5h' });
  res.json({ token });
};

exports.getAllUsers = (req, res) => {
  const users = loadUsers().map(u => ({
    email: u.email,
    username: u.username,
    lastActive: u.lastActive,
    role: u.role
  }));
  res.json(users);
};

exports.getProfile = (req, res) => {
  const user = loadUsers().find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ message: 'Kullanıcı bulunamadı' });
  res.json({ email: user.email, username: user.username, role: user.role });
};

exports.updateProfile = (req, res) => {
  const { username, password, confirmPassword } = req.body;
  const users = loadUsers();
  const user = users.find(u => u.id === req.user.id);
  if (!user) return res.status(404).json({ message: 'Kullanıcı bulunamadı' });

  if (username) user.username = username;
  if (password) {
    if (password !== confirmPassword) return res.status(400).json({ message: 'Şifreler uyuşmuyor' });
    user.password = bcrypt.hashSync(password, 10);
  }

  saveUsers(users);
  res.json({ message: 'Profil güncellendi' });
};

exports.resetPasswordRequest = (req, res) => {
  const { email } = req.body;
  const user = findUserByEmail(email);
  if (!user) return res.status(404).json({ message: 'Kullanıcı bulunamadı' });

  const resetToken = uuidv4();
  user.resetToken = resetToken;
  user.resetTokenExpiry = Date.now() + 1000 * 60 * 15; // 15 dakika geçerli
  saveUsers(loadUsers().map(u => (u.email === email ? user : u)));

  const link = `http://localhost:3000/reset-password?token=${resetToken}`;
  sendMail(user.email, 'Şifre Sıfırlama', `Şifrenizi sıfırlamak için bağlantıya tıklayın: ${link}`);
  res.json({ message: 'Şifre sıfırlama bağlantısı e-posta adresinize gönderildi' });
};

exports.resetPassword = (req, res) => {
  const { token, newPassword, confirmPassword } = req.body;
  const users = loadUsers();
  const user = users.find(u => u.resetToken === token && u.resetTokenExpiry > Date.now());
  if (!user) return res.status(400).json({ message: 'Geçersiz veya süresi dolmuş bağlantı' });

  if (newPassword !== confirmPassword) {
    return res.status(400).json({ message: 'Şifreler uyuşmuyor' });
  }

  user.password = bcrypt.hashSync(newPassword, 10);
  delete user.resetToken;
  delete user.resetTokenExpiry;
  saveUsers(users);
  res.json({ message: 'Şifre başarıyla güncellendi' });
};
