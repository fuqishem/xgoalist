const fs = require('fs');
const path = require('path');

const layoutFile = path.join(__dirname, '..', 'data', 'layouts.json');

// JSON dosyasını oku
function readLayouts() {
  if (!fs.existsSync(layoutFile)) return { header: [], footer: [] };
  const data = fs.readFileSync(layoutFile, 'utf-8');
  return JSON.parse(data);
}

// JSON dosyasına yaz
function writeLayouts(data) {
  fs.writeFileSync(layoutFile, JSON.stringify(data, null, 2), 'utf-8');
}

// Tüm layoutları getir
exports.getLayouts = (req, res) => {
  const layouts = readLayouts();
  res.json(layouts);
};

// Yeni bileşen ekle (header/footer)
exports.addLayout = (req, res) => {
  const { type, content, position } = req.body;
  if (!['header', 'footer'].includes(type)) {
    return res.status(400).json({ message: 'Geçersiz tür' });
  }

  const layouts = readLayouts();
  layouts[type].push({ content, position });
  writeLayouts(layouts);
  res.json({ message: `${type} bileşeni eklendi.` });
};

// Layout bileşenini sil
exports.deleteLayout = (req, res) => {
  const { type, index } = req.params;
  const layouts = readLayouts();
  if (!layouts[type] || !layouts[type][index]) {
    return res.status(404).json({ message: 'Bileşen bulunamadı.' });
  }

  layouts[type].splice(index, 1);
  writeLayouts(layouts);
  res.json({ message: 'Bileşen silindi.' });
};
