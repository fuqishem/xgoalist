const jwt = require('jsonwebtoken');
const SECRET_KEY = 'xgoalist_secret_key';

function verifyAdmin(req, res, next){
  const authHeader = req.headers['authorization'];
  if(!authHeader) return res.status(403).json({ message:'Token gerekli' });

  jwt.verify(authHeader, SECRET_KEY, (err, decoded) => {
    if(err) return res.status(401).json({ message:'Geçersiz token' });
    req.user = decoded;
    next();
  });
}

module.exports = verifyAdmin;
