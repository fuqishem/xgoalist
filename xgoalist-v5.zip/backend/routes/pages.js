const express = require('express');
const fs = require('fs');
const path = require('path');
const verifyAdmin = require('../middleware/auth');

const router = express.Router();
const pagesPath = path.join(__dirname, '../data/pages.json');

// Tüm sayfaları getir
router.get('/', (req, res) => {
  const pages = JSON.parse(fs.readFileSync(pagesPath));
  res.json(pages);
});

// Yeni sayfa ekle
router.post('/', verifyAdmin, (req, res) => {
  const { title, slug, content, parent, visibility, rolesAllowed } = req.body;

  if (!title || !slug) {
    return res.status(400).json({ message: 'Başlık ve slug zorunludur' });
  }

  const pages = JSON.parse(fs.readFileSync(pagesPath));

  // Slug benzersiz olmalı
  if (pages.find(p => p.slug === slug)) {
    return res.status(400).json({ message: 'Bu slug zaten mevcut' });
  }

  const newPage = {
    title,
    slug,
    content: content || '',
    parent: parent || null,
    visibility: visibility || 'public',
    rolesAllowed: rolesAllowed || [],
    children: [],
    date: new Date().toISOString()
  };

  // Eğer parent varsa, çocuk olarak ekle
  if (parent) {
    const parentPage = pages.find(p => p.slug === parent);
    if (parentPage) parentPage.children.push(newPage);
  }

  pages.push(newPage);
  fs.writeFileSync(pagesPath, JSON.stringify(pages, null, 2));

  res.status(201).json({ message: 'Sayfa eklendi', page: newPage });
});

// Sayfa düzenle
router.put('/:slug', verifyAdmin, (req, res) => {
  const { slug } = req.params;
  const { title, content, parent, visibility, rolesAllowed } = req.body;

  const pages = JSON.parse(fs.readFileSync(pagesPath));
  const pageIndex = pages.findIndex(p => p.slug === slug);

  if (pageIndex === -1) return res.status(404).json({ message: 'Sayfa bulunamadı' });

  pages[pageIndex] = {
    ...pages[pageIndex],
    title: title || pages[pageIndex].title,
    content: content !== undefined ? content : pages[pageIndex].content,
    parent: parent !== undefined ? parent : pages[pageIndex].parent,
    visibility: visibility || pages[pageIndex].visibility,
    rolesAllowed: rolesAllowed || pages[pageIndex].rolesAllowed,
    date: new Date().toISOString()
  };

  fs.writeFileSync(pagesPath, JSON.stringify(pages, null, 2));
  res.json({ message: 'Sayfa güncellendi', page: pages[pageIndex] });
});

// Sayfa sil
router.delete('/:slug', verifyAdmin, (req, res) => {
  const { slug } = req.params;
  let pages = JSON.parse(fs.readFileSync(pagesPath));

  const pageIndex = pages.findIndex(p => p.slug === slug);
  if (pageIndex === -1) return res.status(404).json({ message: 'Sayfa bulunamadı' });

  const deletedPage = pages.splice(pageIndex, 1);
  fs.writeFileSync(pagesPath, JSON.stringify(pages, null, 2));

  res.json({ message: 'Sayfa silindi', deleted: deletedPage });
});

// Frontend’de sayfa görüntüleme (rol kontrolü ileride eklenecek)
router.get('/view/:slug', (req, res) => {
  const pages = JSON.parse(fs.readFileSync(pagesPath));
  const page = pages.find(p => p.slug === req.params.slug);
  if (!page) return res.status(404).json({ message: 'Sayfa bulunamadı' });
  res.json(page);
});

module.exports = router;
