const express = require('express');
const fs = require('fs');
const path = require('path');
const multer = require('multer');

const router = express.Router();

const adsPath = path.join(__dirname, '../data/ads.json');
const uploadDir = path.join(__dirname, '../uploads');

// Yükleme klasörü yoksa oluştur
if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir, { recursive: true });

// Multer konfigürasyonu (banner/görsel yükleme)
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// Tüm reklamları getir
router.get('/', (req, res) => {
  const ads = JSON.parse(fs.readFileSync(adsPath));
  res.json(ads);
});

// Yeni reklam ekle (görsel + link)
router.post('/', upload.single('image'), (req, res) => {
  const { link } = req.body;
  if (!req.file || !link) {
    return res.status(400).json({ message: 'Görsel ve link gerekli' });
  }

  const ads = JSON.parse(fs.readFileSync(adsPath));
  const newAd = {
    image: `/uploads/${req.file.filename}`,
    link,
    date: new Date().toISOString()
  };

  ads.push(newAd);
  fs.writeFileSync(adsPath, JSON.stringify(ads, null, 2));
  res.status(201).json({ message: 'Reklam eklendi', ad: newAd });
});

// Reklam sil
router.delete('/:index', (req, res) => {
  const index = parseInt(req.params.index);
  const ads = JSON.parse(fs.readFileSync(adsPath));

  if (index >= 0 && index < ads.length) {
    const deleted = ads.splice(index, 1);
    fs.writeFileSync(adsPath, JSON.stringify(ads, null, 2));
    res.json({ message: 'Reklam silindi', deleted });
  } else {
    res.status(404).json({ message: 'Reklam bulunamadı' });
  }
});

module.exports = router;
