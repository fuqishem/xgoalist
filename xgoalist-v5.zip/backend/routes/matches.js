const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const matchController = require('../controllers/matchController');

// Tüm maçları getir
router.get('/', matchController.getAllMatches);

// Maç ekle
router.post('/', auth, matchController.addMatch);

// Maç sil
router.delete('/:index', auth, matchController.deleteMatch);

// Öne çıkarma / kaldırma
router.patch('/feature/:index', auth, matchController.toggleFeatured);

module.exports = router;
