const express = require('express');
const router = express.Router();
const popupController = require('../controllers/popupController');
const verifyAdmin = require('../middleware/auth');

// Tüm popupları getir
router.get('/', popupController.getAllPopups);

// Belirli bir popup'ı getir
router.get('/:id', popupController.getPopupById);

// Yeni popup oluştur
router.post('/', verifyAdmin, popupController.createPopup);

// Popup güncelle
router.put('/:id', verifyAdmin, popupController.updatePopup);

// Popup sil
router.delete('/:id', verifyAdmin, popupController.deletePopup);

module.exports = router;
