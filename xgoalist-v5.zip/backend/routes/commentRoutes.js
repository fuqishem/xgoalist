const express = require('express');
const router = express.Router();
const commentController = require('../controllers/commentController');
const verifyAdmin = require('../middleware/auth');

// Tüm yorumları al
router.get('/', verifyAdmin, commentController.getAllComments);

// Yorum ekle (kullanıcılar için açık)
router.post('/', commentController.addComment);

// Yorum sil (sadece admin)
router.delete('/:index', verifyAdmin, commentController.deleteComment);

module.exports = router;
