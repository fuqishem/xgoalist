const express = require('express');
const fs = require('fs');
const path = require('path');
const jwt = require('jsonwebtoken');

const router = express.Router();

const commentsPath = path.join(__dirname, '../data/comments.json');
const SECRET_KEY = 'xgoalist_secret_key';

// JWT doğrulama middleware
function verifyToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  if (!authHeader) return res.status(403).json({ message: 'Token gerekli' });

  const token = authHeader.split(' ')[1] || authHeader; // Bearer kontrolü
  jwt.verify(token, SECRET_KEY, (err, decoded) => {
    if (err) return res.status(401).json({ message: 'Geçersiz token' });
    req.user = decoded;
    next();
  });
}

// Belirli maçın yorumlarını getir
router.get('/:matchIndex', (req, res) => {
  const matchIndex = parseInt(req.params.matchIndex);
  const comments = JSON.parse(fs.readFileSync(commentsPath));
  const matchComments = comments.filter(c => c.matchIndex === matchIndex);
  res.json(matchComments);
});

// Tüm yorumları listele (Admin için)
router.get('/', (req, res) => {
  const comments = JSON.parse(fs.readFileSync(commentsPath));
  res.json(comments);
});

// Yeni yorum ekle (JWT doğrulamalı)
router.post('/', verifyToken, (req, res) => {
  const { matchIndex, comment, prediction } = req.body;
  if (matchIndex === undefined || !comment || !prediction) {
    return res.status(400).json({ message: 'Eksik veri' });
  }

  const comments = JSON.parse(fs.readFileSync(commentsPath));
  comments.push({
    matchIndex,
    username: req.user.username,
    comment,
    prediction,
    date: new Date().toISOString()
  });
  fs.writeFileSync(commentsPath, JSON.stringify(comments, null, 2));
  res.status(201).json({ message: 'Yorum eklendi' });
});

// Yorum sil (Admin panel için)
router.delete('/:index', (req, res) => {
  const index = parseInt(req.params.index);
  const comments = JSON.parse(fs.readFileSync(commentsPath));

  if (index >= 0 && index < comments.length) {
    const deleted = comments.splice(index, 1);
    fs.writeFileSync(commentsPath, JSON.stringify(comments, null, 2));
    res.json({ message: 'Yorum silindi', deleted });
  } else {
    res.status(404).json({ message: 'Yorum bulunamadı' });
  }
});

module.exports = router;
