const express = require('express');
const fs = require('fs');
const path = require('path');

const router = express.Router();

const layoutPath = path.join(__dirname, '../data/layout.json');

// Mevcut layout bilgisini getir
router.get('/', (req, res) => {
  const layout = JSON.parse(fs.readFileSync(layoutPath));
  res.json(layout);
});

// Layout bilgisini güncelle (header/footer)
router.put('/', (req, res) => {
  const { headerLinks, footerLinks, socialLinks } = req.body;
  const layout = JSON.parse(fs.readFileSync(layoutPath));

  const newLayout = {
    headerLinks: headerLinks || layout.headerLinks,
    footerLinks: footerLinks || layout.footerLinks,
    socialLinks: socialLinks || layout.socialLinks,
    updated: new Date().toISOString()
  };

  fs.writeFileSync(layoutPath, JSON.stringify(newLayout, null, 2));
  res.json({ message: 'Layout güncellendi', layout: newLayout });
});

module.exports = router;
