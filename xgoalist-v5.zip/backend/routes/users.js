const express = require('express');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const router = express.Router();

const usersPath = path.join(__dirname, '../data/users.json');
const SECRET_KEY = 'xgoalist_secret_key';

// Kullanıcı listesi (opsiyonel)
router.get('/', (req, res) => {
  const users = JSON.parse(fs.readFileSync(usersPath));
  res.json(users.map(u => ({ username: u.username, date: u.date })));
});

// Kullanıcı kayıt
router.post('/register', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ message: 'Kullanıcı adı ve şifre gerekli' });
  }

  const users = JSON.parse(fs.readFileSync(usersPath));
  if (users.find(u => u.username === username)) {
    return res.status(409).json({ message: 'Kullanıcı zaten mevcut' });
  }

  const hashedPassword = await bcrypt.hash(password, 10);
  users.push({ username, password: hashedPassword, date: new Date().toISOString() });
  fs.writeFileSync(usersPath, JSON.stringify(users, null, 2));
  res.status(201).json({ message: 'Kayıt başarılı' });
});

// Kullanıcı girişi (JWT üretir)
router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const users = JSON.parse(fs.readFileSync(usersPath));
  const user = users.find(u => u.username === username);

  if (!user) return res.status(401).json({ message: 'Kullanıcı bulunamadı' });

  const isPasswordValid = await bcrypt.compare(password, user.password);
  if (!isPasswordValid) return res.status(401).json({ message: 'Şifre hatalı' });

  const token = jwt.sign({ username }, SECRET_KEY, { expiresIn: '2h' });
  res.json({ message: 'Giriş başarılı', token });
});

module.exports = router;
