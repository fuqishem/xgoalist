// backend/controllers/userController.js
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const nodemailer = require('nodemailer');
const usersFilePath = path.join(__dirname, '../data/users.json');
const SECRET_KEY = 'xgoalist_secret_key';

function readUsers() {
  if (!fs.existsSync(usersFilePath)) return [];
  return JSON.parse(fs.readFileSync(usersFilePath));
}

function writeUsers(users) {
  fs.writeFileSync(usersFilePath, JSON.stringify(users, null, 2));
}

// Kayıt Ol
function register(req, res) {
  const { email, username, password, confirmPassword, agreementAccepted } = req.body;
  if (!email || !username || !password || !confirmPassword || !agreementAccepted) {
    return res.status(400).json({ message: 'Tüm alanlar zorunlu' });
  }
  if (password !== confirmPassword) {
    return res.status(400).json({ message: 'Şifreler uyuşmuyor' });
  }

  const users = readUsers();
  if (users.find(u => u.email === email)) {
    return res.status(400).json({ message: 'Bu e-posta zaten kayıtlı' });
  }

  const hashedPassword = bcrypt.hashSync(password, 10);
  const newUser = {
    id: uuidv4(),
    email,
    username,
    password: hashedPassword,
    role: 'user',
    createdAt: new Date(),
    lastActive: new Date()
  };
  users.push(newUser);
  writeUsers(users);
  res.json({ message: 'Kayıt başarılı' });
}

// Giriş Yap
function login(req, res) {
  const { email, password } = req.body;
  const users = readUsers();
  const user = users.find(u => u.email === email);
  if (!user) return res.status(400).json({ message: 'Kullanıcı bulunamadı' });
  if (!bcrypt.compareSync(password, user.password)) {
    return res.status(401).json({ message: 'Şifre yanlış' });
  }

  user.lastActive = new Date();
  writeUsers(users);

  const token = jwt.sign({ email: user.email, role: user.role }, SECRET_KEY);
  res.json({ message: 'Giriş başarılı', token });
}

// Kullanıcıları Listele
function listUsers(req, res) {
  const users = readUsers().map(u => ({
    username: u.username,
    email: u.email,
    lastActive: u.lastActive
  }));
  res.json(users);
}

// Şifremi Unuttum
function forgotPassword(req, res) {
  const { email } = req.body;
  const users = readUsers();
  const user = users.find(u => u.email === email);
  if (!user) return res.status(404).json({ message: 'Kullanıcı bulunamadı' });

  const resetToken = uuidv4();
  user.resetToken = resetToken;
  user.resetExpires = Date.now() + 15 * 60 * 1000;
  writeUsers(users);

  const transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: 'example@gmail.com',
      pass: 'password'
    }
  });

  const resetLink = `http://localhost:3000/reset-password/${resetToken}`;
  const mailOptions = {
    from: 'example@gmail.com',
    to: email,
    subject: 'Şifre Sıfırlama',
    text: `Şifrenizi sıfırlamak için şu bağlantıyı kullanın: ${resetLink}`
  };

  transporter.sendMail(mailOptions, (error, info) => {
    if (error) return res.status(500).json({ message: 'Mail gönderilemedi' });
    res.json({ message: 'Şifre sıfırlama e-postası gönderildi' });
  });
}

// Şifre Sıfırlama
function resetPassword(req, res) {
  const { token, newPassword } = req.body;
  const users = readUsers();
  const user = users.find(u => u.resetToken === token && u.resetExpires > Date.now());
  if (!user) return res.status(400).json({ message: 'Token geçersiz veya süresi dolmuş' });

  user.password = bcrypt.hashSync(newPassword, 10);
  delete user.resetToken;
  delete user.resetExpires;
  writeUsers(users);

  res.json({ message: 'Şifre başarıyla güncellendi' });
}

module.exports = {
  register,
  login,
  listUsers,
  forgotPassword,
  resetPassword
};
