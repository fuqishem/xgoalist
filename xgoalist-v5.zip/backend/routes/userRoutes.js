const express = require('express');
const router = express.Router();
const userController = require('../controllers/userController');
const verifyToken = require('../middleware/verifyToken');

// Genel kullanıcı işlemleri
router.post('/register', userController.register);
router.post('/login', userController.login);
router.post('/forgot-password', userController.forgotPassword);
router.post('/reset-password', userController.resetPassword);

// Kullanıcı bilgileri (korumalı)
router.get('/me', verifyToken, userController.getMe);
router.put('/update', verifyToken, userController.updateProfile);
router.put('/change-password', verifyToken, userController.changePassword);
router.post('/logout', verifyToken, userController.logout);

// Admin paneli için kullanıcı listesi
router.get('/', verifyToken, userController.listUsers);

module.exports = router;
