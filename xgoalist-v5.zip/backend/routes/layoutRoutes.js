const express = require('express');
const router = express.Router();
const layoutController = require('../controllers/layoutController');
const authMiddleware = require('../middlewares/auth'); // Admin kontrolü

// Tüm header/footer bileşenlerini al
router.get('/', layoutController.getLayouts);

// Yeni layout (header/footer) bileşeni ekle
router.post('/', authMiddleware, layoutController.addLayout);

// Header/Footer bileşeni sil
router.delete('/:type/:index', authMiddleware, layoutController.deleteLayout);

module.exports = router;
