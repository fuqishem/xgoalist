const dotenv = require('dotenv');
dotenv.config();

module.exports = {
  PORT: process.env.PORT || 3000,
  JWT_SECRET: process.env.JWT_SECRET || 'your_secret_key',
  UPLOAD_DIR: './public/uploads',
  ALLOWED_IMAGE_TYPES: ['image/jpeg', 'image/png', 'image/gif', 'image/webp'],
  MAX_FILE_SIZE_MB: 5,
  INACTIVITY_TIMEOUT_MINUTES: 5
};
