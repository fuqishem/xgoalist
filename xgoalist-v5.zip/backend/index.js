const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');
const fs = require('fs');
require('dotenv').config();

const authRoutes = require('./routes/auth');
const matchRoutes = require('./routes/matches');
const pageRoutes = require('./routes/pages');
const adRoutes = require('./routes/ads');
const userRoutes = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(fileUpload());
app.use(express.static('public'));
app.use('/uploads', express.static(__dirname + '/uploads'));

app.use('/api/auth', authRoutes);
app.use('/api/matches', matchRoutes);
app.use('/api/pages', pageRoutes);
app.use('/api/ads', adRoutes);
app.use('/api/users', userRoutes);
app.use('/api/layouts', require('./routes/layoutRoutes'));


// Ön yüz yönlendirmeleri (örnek)
app.get('/', (req, res) => {
  res.sendFile(__dirname + '/../views/index.html');
});

app.get('/admin', (req, res) => {
  res.sendFile(__dirname + '/../views/login.html');
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
